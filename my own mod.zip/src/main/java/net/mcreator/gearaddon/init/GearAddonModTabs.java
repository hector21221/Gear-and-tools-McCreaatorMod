/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.gearaddon.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.core.registries.Registries;

import net.mcreator.gearaddon.GearAddonMod;

@EventBusSubscriber
public class GearAddonModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, GearAddonMod.MODID);

	@SubscribeEvent
	public static void buildTabContentsVanilla(BuildCreativeModeTabContentsEvent tabData) {
		if (tabData.getTabKey() == CreativeModeTabs.COMBAT) {
			tabData.accept(GearAddonModItems.GLOWSTONESWORD.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) {
			tabData.accept(GearAddonModItems.GLOWSTONEPICKAXE.get());
			tabData.accept(GearAddonModItems.GLOWSTONE_AXE.get());
			tabData.accept(GearAddonModItems.GLOWSTONE_SHOVEL.get());
			tabData.accept(GearAddonModItems.GLOWSTONEHOE.get());
		}
	}
}