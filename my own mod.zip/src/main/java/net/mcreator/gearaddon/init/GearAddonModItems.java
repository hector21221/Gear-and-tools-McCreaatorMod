/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.gearaddon.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredItem;

import net.minecraft.world.item.Item;

import net.mcreator.gearaddon.item.GlowstonepickaxeItem;
import net.mcreator.gearaddon.item.GlowstonehoeItem;
import net.mcreator.gearaddon.item.GlowstoneShovelItem;
import net.mcreator.gearaddon.item.GlowstoneAxeItem;
import net.mcreator.gearaddon.item.GLOWSTONESWORDItem;
import net.mcreator.gearaddon.GearAddonMod;

public class GearAddonModItems {
	public static final DeferredRegister.Items REGISTRY = DeferredRegister.createItems(GearAddonMod.MODID);
	public static final DeferredItem<Item> GLOWSTONESWORD;
	public static final DeferredItem<Item> GLOWSTONEPICKAXE;
	public static final DeferredItem<Item> GLOWSTONE_AXE;
	public static final DeferredItem<Item> GLOWSTONE_SHOVEL;
	public static final DeferredItem<Item> GLOWSTONEHOE;
	static {
		GLOWSTONESWORD = REGISTRY.register("glowstonesword", GLOWSTONESWORDItem::new);
		GLOWSTONEPICKAXE = REGISTRY.register("glowstonepickaxe", GlowstonepickaxeItem::new);
		GLOWSTONE_AXE = REGISTRY.register("glowstone_axe", GlowstoneAxeItem::new);
		GLOWSTONE_SHOVEL = REGISTRY.register("glowstone_shovel", GlowstoneShovelItem::new);
		GLOWSTONEHOE = REGISTRY.register("glowstonehoe", GlowstonehoeItem::new);
	}
	// Start of user code block custom items
	// End of user code block custom items
}